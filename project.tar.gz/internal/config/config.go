package config

import (
	"auth/internal/logging"
	"os"
	"path"
	"strconv"
	"time"

	"github.com/go-playground/validator/v10"
	"github.com/gofor-little/env"
)

type Config struct {
	GRPCServer  *GRPCServer  `validate:"required"`
	HTTPServer  *HTTPServer  `validate:"required"`
	Database    *Database    `validate:"required"`
	Redis       *Redis       `validate:"required"`
	AuthService *AuthService `validate:"required"`
	Metrics     *Metrics     `validate:"required"`
	Tracing     *Tracing     `validate:"required"`
}

type GRPCServer struct {
	Addr string `validate:"required,hostname_port"`
}

type HTTPServer struct {
	Addr string `validate:"required,hostname_port"`
}

type Database struct {
	DSN                 string        `validate:"required"`
	Driver              string        `validate:"required,oneof=postgres sqlite"`
	PoolMaxIdleConns    int           `validate:"gte=0"`
	PoolMaxOpenConns    int           `validate:"gte=0"`
	PoolConnMaxLifetime time.Duration `validate:"gte=0"`
	Logger              logging.Logger
}

type Redis struct {
	Addr         string        `validate:"required"`
	Password     string        `validate:"required"`
	DB           int           `validate:"gte=0"`
	DialTimeout  time.Duration `validate:"gte=0"`
	ReadTimeout  time.Duration `validate:"gte=0"`
	WriteTimeout time.Duration `validate:"gte=0"`
	PoolSize     int           `validate:"gte=0"`
	MinIdleConns int           `validate:"gte=0"`
}

type AuthService struct {
	SecretKey string        `validate:"required"`
	TokenTTL  time.Duration `validate:"required"`
}

type Metrics struct {
	EnableDefaultMetrics bool
}

type Tracing struct {
	ServiceName   string `validate:"required"`
	CollectorAddr string `validate:"required,hostname_port"`
}

type LoaderOpts struct {
	EnvPath   string
	EnvLoader func(string) error
	Logger    logging.Logger
}

func NewConfig() (*Config, error) {
	cwd, err := os.Getwd()
	if err != nil {
		return nil, err
	}
	return NewConfigWithOpts(LoaderOpts{
		EnvPath: getEnv("ENV_CONFIG", path.Join(cwd, ".env")),
	})
}

func NewConfigWithOpts(opts LoaderOpts) (*Config, error) {
	logger := opts.Logger
	if logger == nil {
		logger = logging.New(os.Stderr, "info")
	}

	envLoader := opts.EnvLoader
	if envLoader == nil {
		envLoader = func(path string) error {
			_, err := os.Stat(path)
			if err != nil {
				return err
			}
			return env.Load(path)
		}
	}

	if err := envLoader(opts.EnvPath); err == nil {
		logger.Info("Loaded environment variables from " + opts.EnvPath)
	} else {
		logger.Info("failed to load .env file, using system environment variables")
	}

	cfg := &Config{
		GRPCServer: &GRPCServer{
			Addr: getEnv("GRPC_SERVER_ADDR", ":8080"),
		},
		HTTPServer: &HTTPServer{
			Addr: getEnv("HTTP_SERVER_ADDR", ":8081"),
		},
		Database: &Database{
			DSN:                 getEnv("DATABASE_URL", ""),
			Driver:              getEnv("DATABASE_DRIVER", "postgres"),
			PoolMaxIdleConns:    getEnvInt("DATABASE_POOL_MAX_IDLE", 10),
			PoolMaxOpenConns:    getEnvInt("DATABASE_POOL_MAX_OPEN", 100),
			PoolConnMaxLifetime: getEnvDuration("DATABASE_POOL_MAX_LIFETIME", time.Hour),
		},
		Redis: &Redis{
			Addr:         getEnv("REDIS_ADDR", "localhost:6379"),
			Password:     getEnv("REDIS_PASSWORD", "default"),
			DB:           getEnvInt("REDIS_DB", 0),
			DialTimeout:  getEnvDuration("REDIS_DIAL_TIMEOUT", 5*time.Second),
			ReadTimeout:  getEnvDuration("REDIS_READ_TIMEOUT", 1*time.Second),
			WriteTimeout: getEnvDuration("REDIS_WRITE_TIMEOUT", 1*time.Second),
			PoolSize:     getEnvInt("REDIS_POOL_SIZE", 20),
			MinIdleConns: getEnvInt("REDIS_MIN_IDLE_CONNS", 5),
		},
		AuthService: &AuthService{
			SecretKey: getEnv("AUTH_SECRET_KEY", "super_secret_key"),
			TokenTTL:  getEnvDuration("AUTH_TOKEN_TTL", 30*time.Minute),
		},
		Metrics: &Metrics{
			EnableDefaultMetrics: getEnvBool("METRICS_ENABLE_DEFAULT_METRICS", true),
		},
		Tracing: &Tracing{
			ServiceName:   getEnv("TRACING_SERVICE_NAME", "auth-service"),
			CollectorAddr: getEnv("TRACING_COLLECTOR_ADDR", "localhost:4318"),
		},
	}

	validate := validator.New()
	if err := validate.Struct(cfg); err != nil {
		return nil, err
	}

	return cfg, nil
}

func getEnv(key, defaultVal string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return defaultVal
}

func getEnvInt(key string, defaultVal int) int {
	if value, exists := os.LookupEnv(key); exists {
		if parsedValue, err := strconv.Atoi(value); err == nil {
			return parsedValue
		}
	}
	return defaultVal
}

func getEnvDuration(key string, defaultVal time.Duration) time.Duration {
	if value, exists := os.LookupEnv(key); exists {
		if parsedValue, err := time.ParseDuration(value); err == nil {
			return parsedValue
		}
	}
	return defaultVal
}

func getEnvBool(key string, defaultVal bool) bool {
	if value, exists := os.LookupEnv(key); exists {
		if parsedValue, err := strconv.ParseBool(value); err == nil {
			return parsedValue
		}
	}
	return defaultVal
}
