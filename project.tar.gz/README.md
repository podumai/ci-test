# auth-service
Authentication service for "Geo Assistant Application".
