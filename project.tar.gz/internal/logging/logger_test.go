package logging

import (
	"bytes"
	"encoding/json"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"testing"
)

func parseLog(t *testing.T, buf *bytes.Buffer) map[string]any {
	t.Helper()
	var logEntry map[string]any
	err := json.Unmarshal(buf.Bytes(), &logEntry)
	require.NoError(t, err)
	return logEntry
}

func TestNewZerologLogger_DefaultLevel(t *testing.T) {
	var buf bytes.Buffer
	l := New(&buf, "random_level")
	l.Info("test", Field{Key: "key", Value: "value"})
	entry := parseLog(t, &buf)

	assert.Equal(t, "info", entry["level"])
	assert.Equal(t, "value", entry["key"])
	assert.Equal(t, "test", entry["message"])
}

func TestNewZerologLogger_DefaultWriter(t *testing.T) {
	var buf bytes.Buffer
	l := New(&buf, "info")
	l.Info("test", Field{Key: "key", Value: "value"})
	entry := parseLog(t, &buf)

	assert.Equal(t, "info", entry["level"])
	assert.Equal(t, "value", entry["key"])
	assert.Equal(t, "test", entry["message"])
}
