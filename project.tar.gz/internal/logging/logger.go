package logging

import (
	"io"
	"os"

	"github.com/rs/zerolog"
)

type Field struct {
	Key   string
	Value any
}

type Logger interface {
	Error(msg string, fields ...Field)
	Warn(msg string, fields ...Field)
	Info(msg string, fields ...Field)
	Debug(msg string, fields ...Field)
	Trace(msg string, fields ...Field)
	Fatal(msg string, fields ...Field)
	Panic(msg string, fields ...Field)
}

type ZerologLogger struct {
	logger zerolog.Logger
}

func (zl *ZerologLogger) Info(msg string, fields ...Field) {
	event := zl.logger.Info()
	for _, field := range fields {
		event.Any(field.Key, field.Value)
	}
	event.Msg(msg)
}

func (zl *ZerologLogger) Warn(msg string, fields ...Field) {
	event := zl.logger.Warn()
	for _, field := range fields {
		event.Any(field.Key, field.Value)
	}
	event.Msg(msg)
}

func (zl *ZerologLogger) Error(msg string, fields ...Field) {
	event := zl.logger.Error()
	for _, field := range fields {
		event.Any(field.Key, field.Value)
	}
	event.Msg(msg)
}

func (zl *ZerologLogger) Debug(msg string, fields ...Field) {
	event := zl.logger.Debug()
	for _, field := range fields {
		event.Any(field.Key, field.Value)
	}
	event.Msg(msg)
}

func (zl *ZerologLogger) Trace(msg string, fields ...Field) {
	event := zl.logger.Trace()
	for _, field := range fields {
		event.Any(field.Key, field.Value)
	}
	event.Msg(msg)
}

func (zl *ZerologLogger) Fatal(msg string, fields ...Field) {
	event := zl.logger.Fatal()
	for _, field := range fields {
		event.Any(field.Key, field.Value)
	}
	event.Msg(msg)
}

func (zl *ZerologLogger) Panic(msg string, fields ...Field) {
	event := zl.logger.Panic()
	for _, field := range fields {
		event.Any(field.Key, field.Value)
	}
	event.Msg(msg)
}

func init() {
	zerolog.TimeFieldFormat = zerolog.TimeFormatUnix
}

func New(output io.Writer, level string) *ZerologLogger {
	if output == nil {
		output = os.Stderr
	}
	loggerLevel, err := zerolog.ParseLevel(level)
	if err != nil {
		loggerLevel = zerolog.InfoLevel
	}
	logger := zerolog.New(output).With().Timestamp().Logger().Level(loggerLevel)
	return &ZerologLogger{logger: logger}
}
