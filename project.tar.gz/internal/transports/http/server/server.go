package server

import (
	"auth/internal/cache"
	"auth/internal/config"
	"auth/internal/database"
	"auth/internal/logging"
	"auth/internal/observability/metrics"
	"auth/internal/service"
	"auth/internal/transports/http/handler"
	"errors"
	"net"
	"net/http"
)

type Opts struct {
	Config   *config.HTTPServer
	Logger   logging.Logger
	Database database.DatabaseService
	Cache    cache.CacheService
	Metrics  metrics.MetricsService
	Health   service.HealthService
}

type HTTPServer struct {
	Config *config.HTTPServer
	Server *http.Server
	Logger logging.Logger
}

func NewHTTPServer(opts *Opts) *HTTPServer {
	mux := http.NewServeMux()
	healthHandler := handler.NewHealthHandler(&handler.Opts{
		HealthService: opts.Health,
		Logger:        opts.Logger,
	})

	mux.HandleFunc("GET /live", healthHandler.Live)
	mux.HandleFunc("GET /ready", healthHandler.Ready)
	mux.Handle("GET /metrics", opts.Metrics.Handler())

	return &HTTPServer{
		Config: opts.Config,
		Server: &http.Server{
			Addr:    opts.Config.Addr,
			Handler: mux,
		},
		Logger: opts.Logger,
	}
}

func (s *HTTPServer) ServeListener(listener net.Listener) error {
	s.Logger.Info("HTTP server started", logging.Field{Key: "address", Value: listener.Addr().String()})
	if err := s.Server.Serve(listener); err != nil && !errors.Is(err, http.ErrServerClosed) {
		s.Logger.Error("HTTP server failed", logging.Field{Key: "error", Value: err.Error()})
		return err
	}
	return nil
}

func (s *HTTPServer) Serve() error {
	listener, err := net.Listen("tcp", s.Config.Addr)
	if err != nil {
		s.Logger.Error("Failed to create HTTP listener",
			logging.Field{Key: "address", Value: s.Config.Addr},
			logging.Field{Key: "error", Value: err.Error()},
		)
		return err
	}
	return s.ServeListener(listener)
}
