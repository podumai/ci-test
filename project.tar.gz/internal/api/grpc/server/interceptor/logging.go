package interceptor

import (
	"auth/internal/logging"
	"context"
	"fmt"
	"time"

	"google.golang.org/grpc"
)

func LoggingInterceptor(logger logging.Logger) grpc.UnaryServerInterceptor {
	return func(
		ctx context.Context,
		request any,
		info *grpc.UnaryServerInfo,
		handler grpc.UnaryHandler,
	) (any, error) {
		start := time.Now()
		response, err := handler(ctx, request)
		elapsedTime := fmt.Sprintf("%.2fms", time.Since(start).Seconds()*1000)

		if err == nil {
			logger.Info("gRPC request completed",
				logging.Field{Key: "method", Value: info.FullMethod},
				logging.Field{Key: "duration", Value: elapsedTime},
			)
		} else {
			logger.Error("gRPC request failed",
				logging.Field{Key: "method", Value: info.FullMethod},
				logging.Field{Key: "duration", Value: elapsedTime},
				logging.Field{Key: "error", Value: err},
			)
		}
		return response, err
	}
}
